function openGame(gameUrl) {
    window.location.href = gameUrl; // गेम पेज का URL
}
